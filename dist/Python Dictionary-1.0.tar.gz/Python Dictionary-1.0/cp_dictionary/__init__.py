from .dictionary import list_of_words, generator_of_words
