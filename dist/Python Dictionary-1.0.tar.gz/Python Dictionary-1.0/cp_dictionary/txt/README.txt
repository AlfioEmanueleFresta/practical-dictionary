This dictionary is all lowercase ASCII, even normally cased characters. 

source:
http://www.mieliestronk.com/corncob_lowercase.txt

word distribution (no chars, count)
1  2
2  47
3  589
4  2294
5  4266
6  6936
7  9203
8  9396
9  7696
10 6377
11 4557
12 3101
13 1880
14 924
15 493
16 193
17 99
18 38
19 9
20 0

Total: 58110